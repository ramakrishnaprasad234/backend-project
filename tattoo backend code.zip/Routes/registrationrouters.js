const express = require('express')
const registation = require('../Controllers/registationController')

const router = express.Router()

router.post("/Register",registation.registrations)


module.exports = router